// Name: Oyedeji Robert Oladayo
// File: a01q02.cpp

#include <iostream>

int main()
{
    std::cout << "Table of cubes\n"
              << "==============\n\n"
              << "n       n^3\n"
              << "---     ---\n"
              << "0       0\n"
              << "1       1\n"
              << "2       8\n"
              << "3       27\n"
              << "4       64\n\n";
    
    return 0;
    
}
