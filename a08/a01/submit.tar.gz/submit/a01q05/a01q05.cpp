// Name: Oyedeji Robert Oladayo
// File: a01q05.cpp

#include <iostream>

int main()
{
    std::cout << "#include <iostream>\n\n"
              << "int main()\n"
              << "{\n"
              << "     std::cout << \"Hello, world!\\n\";\n\n"
              << "     return 0;\n"
              << "}\n\n";
    
    return 0;
}
